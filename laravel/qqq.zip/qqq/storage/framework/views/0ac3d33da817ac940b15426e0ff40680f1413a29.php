Botswana Install Trailers


<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('file-export-botswana-install-trailers')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!--
        <label for="accountNumber">Account Number</label>
        <input type="number" id="accountNumber" name="accountNumber">

        <label for="actionDate">Date:</label>
        <input type="date" id="actionDate" name="actionDate">
        -->
        <label for="actionDate">Action Date:</label>
        <input type="date" id="actionDate" name="actionDate">

        <button class="btn btn-success">Download</button>
        <a class="btn btn-danger" href="<?php echo e(route('file-delete-namibia')); ?>">DeleteX</a>
        <a class="btn btn-primary" href="<?php echo e(route('file-import')); ?>">Back</a>
</form>
<table class="table table-bordered">
    <tr>
        <th>Record</th>
        <th>Volume No.</th>
        <th>Tape Serial No.</th>
        <th>Installation ID from</th>
        <th>To</th>
        <th>Creation Date</th>
        <th>Purge Date</th>
        <th>Generation No.</th>
        <th>Block Length</th>
        <th>Record Length</th>
        <th>Service</th>
        <th>Block Count</th>
        <th>Record Count</th>
        <th>Header Trailer Count</th>
    </tr>
    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($row->RecordIdentifier); ?></td>
        <td><?php echo e($row->VolumeNumber); ?></td>
        <td><?php echo e($row->TapeSerialNumber); ?></td>
        <td><?php echo e($row->InstallationIDfrom); ?></td>
        <td><?php echo e($row->InstallationIDto); ?></td>
        <td><?php echo e($row->CreationDate); ?></td>
        <td><?php echo e($row->PurgeDate); ?></td>
        <td><?php echo e($row->GenerationNumber); ?></td>
        <td><?php echo e($row->BlockLength); ?></td>
        <td><?php echo e($row->RecordLength); ?></td>
        <td><?php echo e($row->Service); ?></td>
        <td><?php echo e($row->BlockCount); ?></td>
        <td><?php echo e($row->RecordCount); ?></td>
        <td><?php echo e($row->UserHeaderTrailerCount); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $table->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shawnwhelan/Sites/localhost/UploadExport/laravel/resources/views/FileImport/file-export-botswanaInstallTrailers-index.blade.php ENDPATH**/ ?>