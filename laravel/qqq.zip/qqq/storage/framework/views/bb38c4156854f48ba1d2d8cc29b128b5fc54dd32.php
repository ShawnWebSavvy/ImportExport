<!DOCTYPE html>
<html lang="<?php echo e(Lang::getLocale()); ?>" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>File Upload Export</title>

    <meta name="author" content="" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="application-name" content="" />

    <!-- Styles -->

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">


</head>
<body class="fixed-left">

    <div id="wrapper">
        <div id="app">
            <div class="content-page">
                <div class="content">

                    <div id="pjax-container" class="container">
                        <div class="row">
                        </div>
                    </div>

                </div>
            </div>

            <a href="#" class="scrollup"> <i class="fa fa-arrow-up"></i></a>

        </div>


        <!-- Right Sidebar -->


    </div>

    <!-- JavaScripts -->



    <!-- Analytics -->


</body>


</html>
<?php /**PATH /Users/shawnwhelan/Sites/localhost/UploadExport/laravel/resources/views/layouts/app.blade.php ENDPATH**/ ?>