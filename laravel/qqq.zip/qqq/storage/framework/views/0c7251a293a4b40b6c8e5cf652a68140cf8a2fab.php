Botswana Contra


<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('file-export-botswana-contras')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!--
        <label for="accountNumber">Account Number</label>
        <input type="number" id="accountNumber" name="accountNumber">

        <label for="actionDate">Date:</label>
        <input type="date" id="actionDate" name="actionDate">
        -->
        <label for="actionDate">Action Date:</label>
        <input type="date" id="actionDate" name="actionDate">

        <button class="btn btn-success">Download</button>
        <a class="btn btn-danger" href="<?php echo e(route('file-delete-namibia')); ?>">DeleteX</a>
        <a class="btn btn-primary" href="<?php echo e(route('file-import')); ?>">Back</a>
</form>
<table class="table table-bordered">
    <tr>
        <th>Record</th>
        <th>User Branch</th>
        <th>User Code</th>
        <th>Sequence No.</th>
        <th>Homing Branch</th>
        <th>Homing Acc No.</th>
        <th>Account Type</th>
        <th>Amount</th>
        <th>Action Date</th>
        <th>Entry</th>
        <th>Abbreviated Name</th>
        <th>Reference</th>
        <th>Acc Name</th>
    </tr>
    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($row->RecordIdentifier); ?></td>
        <td><?php echo e($row->UserBranch); ?></td>
        <td><?php echo e($row->UserCode); ?></td>
        <td><?php echo e($row->SequenceNumber); ?></td>
        <td><?php echo e($row->HomingBranch); ?></td>
        <td><?php echo e($row->HomingAccountNumber); ?></td>
        <td><?php echo e($row->AccountType); ?></td>
        <td><?php echo e($row->Amount); ?></td>
        <td><?php echo e($row->ActionDate); ?></td>
        <td><?php echo e($row->EntryType); ?></td>
        <td><?php echo e($row->UserAbbreviatedName); ?></td>
        <td><?php echo e($row->UserReference); ?></td>
        <td><?php echo e($row->AccountName); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $table->links(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shawnwhelan/Sites/localhost/UploadExport/laravel/resources/views/FileImport/file-export-botswanaContras-index.blade.php ENDPATH**/ ?>