 

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    <form action="<?php echo e(route('file-export-botswana')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4>Botswana Records</h4>
                            </br>
                            <!--
                            <label for="accountNumber">Account Number</label>
                            <input type="number" id="accountNumber" name="accountNumber">

                            <label for="actionDate">Date:</label>
                            <input type="date" id="actionDate" name="actionDate">
                            -->
                            <label for="actionDate">Action Date From:</label>
                            <input type="date" id="actionDateFrom" name="actionDateFrom">
                            <label for="actionDate">To:</label>
                            <input type="date" id="actionDateTo" name="actionDateTo">

                            <button class="btn btn-success">Download</button>
                            <a class="btn btn-danger" href="<?php echo e(route('file-delete-namibia')); ?>">Delete</a>
                            <a class="btn btn-primary" href="<?php echo e(route('file-import')); ?>">Back</a>
                    </form>
                    </br></br>
                    <table class="table table-bordered">
                        <tr>
                            <th>Name</th>
                            <th>Surname</th>
                            <th>ID Number</th>
                            <th>Branch</th>
                            <th>Acc No.</th>
                            <th>Non Standard Acc No.</th>
                            <th>Acc Type</th>
                            <th>Acc Ref</th>

                            <th>Amount</th>
                            <th>Policy No.</th>
                            <th>Action Date</th>
                            <th>Batch ID</th>
                            
                            
                        </tr>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->RecipientAccountHolderName); ?></td>
                            <td><?php echo e($row->RecipientAccountHolderSurname); ?></td>
                            <td><?php echo e($row->RecipientID); ?></td>
                            <td><?php echo e($row->BranchCode); ?></td>
                            <td><?php echo e($row->RecipientAccountNumber); ?></td>
                            <td><?php echo e($row->RecipientNonStandardAccountNumber); ?></td>
                            <td><?php echo e($row->RecipientAccountType); ?></td>
                            <td><?php echo e($row->AccountReference); ?></td>
                            <td><?php echo e($row->RecipientAmount); ?></td>
                            <td><?php echo e($row->PolicyNumber); ?></td>
                            <td><?php echo e($row->ActionDate); ?></td>
                            <td><?php echo e($row->Guid); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo $table->links(); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shawnwhelan/Sites/localhost/ImportExport/laravel/resources/views/FileImport/file-export-botswana-index.blade.php ENDPATH**/ ?>