 

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    <form action="<?php echo e(route('file-export-namibia')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4>Namibia Records</h4>
                            </br>
                            <!--
                            <label for="accountNumber">Account Number</label>
                            <input type="number" id="accountNumber" name="accountNumber">

                            <label for="actionDate">Date:</label>
                            <input type="date" id="actionDate" name="actionDate">
                            -->
                            <label for="actionDate">Action Date:</label>
                            <input type="date" id="actionDate" name="actionDate">

                            <button class="btn btn-success">Download</button>
                            <a class="btn btn-danger" href="<?php echo e(route('file-delete-namibia')); ?>">Delete</a>
                            <a class="btn btn-primary" href="<?php echo e(route('file-import')); ?>">Back</a>
                    </form>
                    </br></br>
                    <table class="table table-bordered">
                        <tr>
                            <th>Name</th>
                            <th>Account Number</th>
                            <th>Action Date</th>
                            <th>Account Type</th>
                            <th>Bic Code</th>
                            <th>Amount</th>
                            <th>Contract Reference</th>
                            <th>Tracking</th>
                            <th>Abbreviated Name</th>
                            <th>Collection</th>
                            <th>Batch ID</th>
                        </tr>
                        <?php $__currentLoopData = $namibia_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->RecipientAccountHolderName); ?></td>
                            <td><?php echo e($row->RecipientAccountNumber); ?></td>
                            <td><?php echo e($row->ActionDate); ?></td>
                            <td><?php echo e($row->RecipientAccountType); ?></td>
                            <td><?php echo e($row->BranchSwiftBicCode); ?></td>
                            <td><?php echo e($row->RecipientAmount); ?></td>
                            <td><?php echo e($row->ContractReference); ?></td>
                            <td><?php echo e($row->Tracking); ?></td>
                            <td><?php echo e($row->RecipientAccountHolderAbbreviatedName); ?></td>
                            <td><?php echo e($row->CollectionReason); ?></td>
                            <td><?php echo e($row->batch_number); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php echo $namibia_table->links(); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shawnwhelan/Sites/localhost/ImportExport/laravel/resources/views/FileImport/file-export-namibia-index.blade.php ENDPATH**/ ?>