<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

li {
  display: inline;
}
</style>

<!DOCTYPE html>
<html>
<head>
    <title>ImportExport</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
</head>
<body>

<ul>
  <li><a href="<?php echo e(route('file-import')); ?>">Home</a></li> | 
  <li><a href="<?php echo e(route('file-export-namibia-index')); ?>">Namibia</a></li> | 
  <li><a href="<?php echo e(route('file-export-botswana-index')); ?>">Botswana</a></li> | 
  <?php if(Route::has('login')): ?>
    <?php if(auth()->guard()->check()): ?>
        <li><a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a></li> | 
      <?php else: ?>
        <li><a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a></li> | 

        <?php if(Route::has('register')): ?>
          <li><a href="<?php echo e(route('register')); ?>" >Register</a></li> | 
        <?php endif; ?>

    <?php endif; ?>

  <?php endif; ?>
  <li><a href="<?php echo e(route('logout')); ?>" >qq</a></li> | 

  <li>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </li> | 

  <li>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']]); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Outt')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </li> | 

  <!-- <li><a href="<?php echo e(route('file-export-botswana-install-headers-index')); ?>">Install Header</a></li> |  -->
  <!-- <li><a href="<?php echo e(route('file-export-botswana-user-headers-index')); ?>">User Header</a></li> |  -->
  <!-- <li><a href="<?php echo e(route('file-export-botswana-contras-index')); ?>">Contras</a></li> |  -->
  <!-- <li><a href="<?php echo e(route('file-export-botswana-transactions-index')); ?>">Transactions</a></li> |  -->
  <!-- <li><a href="<?php echo e(route('file-export-botswana-install-trailers-index')); ?>">Install Trailers</a></li> |  -->
  <!-- <li><a href="<?php echo e(route('file-export-botswana-user-trailers-index')); ?>">User Trailers</a></li> |  -->
 
</ul>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH /Users/shawnwhelan/Sites/localhost/ImportExport/laravel/resources/views/layouts/header.blade.php ENDPATH**/ ?>