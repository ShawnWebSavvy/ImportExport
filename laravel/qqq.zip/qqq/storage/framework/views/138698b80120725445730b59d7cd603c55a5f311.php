
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD Example from scratch - ItSolutionStuff.com</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{ { route('products.create') }}"> Create New Product</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>Name</th>
            <th>Account Number</th>
            <th>Account Type</th>
            <th>Bic Code</th>
            <th>Amount</th>
            <th>Contract Reference</th>
            <th>Tracking</th>
            <th>Abbreviated Name</th>
            <th>Collection</th>
            <th width="400px">Action</th>
        </tr>
        <?php $__currentLoopData = $namibia_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($row->RecipientAccountHolderName); ?></td>
            <td><?php echo e($row->RecipientAccountNumber); ?></td>
            <td><?php echo e($row->RecipientAccountType); ?></td>
            <td><?php echo e($row->BranchSwiftBicCode); ?></td>
            <td><?php echo e($row->RecipientAmount); ?></td>
            <td><?php echo e($row->ContractReference); ?></td>
            <td><?php echo e($row->Tracking); ?></td>
            <td><?php echo e($row->RecipientAccountHolderInitials); ?></td>
            <td><?php echo e($row->CollectionReason); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $namibia_table->links(); ?>

      
<?php /**PATH /Users/shawnwhelan/Sites/localhost/UploadExport/laravel/resources/views/FileImport/file-export.blade.php ENDPATH**/ ?>