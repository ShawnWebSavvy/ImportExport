<form action="<?php echo e(route('file-export-namibia')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!--
        <label for="accountNumber">Account Number</label>
        <input type="number" id="accountNumber" name="accountNumber">

        <label for="date">Date:</label>
        <input type="date" id="date" name="date">
        -->
        <button class="btn btn-primary">Export</button>
</form>
<a class="btn btn-success" href="{ { route('file-export') }}">Delete</a>
<a class="btn btn-success" href="<?php echo e(route('file-import')); ?>">Import</a>
<table class="table table-bordered">
    <tr>
        <th>Name</th>
        <th>Account Number</th>
        <th>Account Type</th>
        <th>Bic Code</th>
        <th>Amount</th>
        <th>Contract Reference</th>
        <th>Tracking</th>
        <th>Abbreviated Name</th>
        <th>Collection</th>
        <th width="400px">Action</th>
    </tr>
    <?php $__currentLoopData = $namibia_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($row->RecipientAccountHolderName); ?></td>
        <td><?php echo e($row->RecipientAccountNumber); ?></td>
        <td><?php echo e($row->RecipientAccountType); ?></td>
        <td><?php echo e($row->BranchSwiftBicCode); ?></td>
        <td><?php echo e($row->RecipientAmount); ?></td>
        <td><?php echo e($row->ContractReference); ?></td>
        <td><?php echo e($row->Tracking); ?></td>
        <td><?php echo e($row->RecipientAccountHolderInitials); ?></td>
        <td><?php echo e($row->CollectionReason); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo $namibia_table->links(); ?>


<?php /**PATH /Users/shawnwhelan/Sites/localhost/UploadExport/laravel/resources/views/FileImport/file-export-namibia.blade.php ENDPATH**/ ?>